import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  
  constructor(props) {
    super(props);

    this.state = {
      searchTerms: '',
    };

    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(e) {
    this.setState({
      searchTerms: e.target.value,
    });
  }

  render() {
    const { articles } = this.props;
    const searchTerms = this.state.searchTerms.trim().toLowerCase();
    let filteredArticles = articles;
    
    // search by filtering

    if (searchTerms.length > 0) {
      filteredArticles = articles.filter((article) => {
        return article.response.toLowerCase().indexOf(searchTerms) !== -1;
      });
    }

    return (
      <form id="app">
        <div className="search">
          <input
            type="text"
            placeholder="Search..."
            onChange={this.handleChange}
          />
        </div>

        <ul>
        // showing the result   
        {filteredArticles.response.docs.map((article,index)    => {
            return (
              <li key={index}>
                <p>{article.snippet}</p>
              </li>
            )
          })}

        </ul>
      </form>
    );
  } 
  
}

export default App;
