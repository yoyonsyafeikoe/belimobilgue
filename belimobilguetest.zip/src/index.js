import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

// collect data here ---------------------------------
const articles = fetch('https://api.nytimes.com/svc/search/v2/articlesearch.json?&api-key=81SlT7KzHfqPrztyHA2X76aCONN1uIpx')
   articles.then( res => {
      if(res.status === 200)
         return res.json()   
   }).then( resJson => {
      this.setState({
          data: resJson
      })
   })

 // inject result from javascript
ReactDOM.render(<App articles={articles} />, document.getElementById('root')); 
